git clean -dfx
python setup.py sdist