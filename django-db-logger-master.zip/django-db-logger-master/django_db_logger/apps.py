from django.apps import AppConfig


class DbLoggerAppConfig(AppConfig):
    name = 'django_db_logger'
    verbose_name = 'Db logging'
